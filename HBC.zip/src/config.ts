import { BotConfig } from './structures/types'; 

export const config: BotConfig = {
    groupId: 8492661,
    slashCommands: true,
    legacyCommands: {
        enabled: true,
        prefixes: [';'],
    },
    permissions: {
        all: ['961930131184705575'],
        ranking: ['961930131184705570', '961930131184705569', '961930131184705567', '961930131184705566', '961930131163725873', '961930131184705572','961930131184705573'],
        users: ['961930131184705570', '961930131184705569', '961930131184705567', '961930131184705566', '961930131163725873', '961930131184705572','961930131184705573', '961930131163725871'],
        shout: [''],
        join: [''],
        signal: [''],
        admin: ['961930131184705575'],
    },
    logChannels: {
        actions: '964224603155202078',
        shout: '',
    },
    database: {
        enabled: false,
        type: 'mongodb',
    },
    api: false,
    maximumRank: 255,
    verificationChecks: true,
    firedRank: 1,
    suspendedRank: 1,
    recordManualActions: true,
    memberCount: {
        enabled: false,
        channelId: '',
        milestone: 100,
        onlyMilestones: false,
    },
    xpSystem: {
        enabled: true,
        autoRankup: false,
        roles: [
            /* Example:
            {
                rank: 3,
                xp: 30,
            },
            */
        ],
    },
    antiAbuse: {
        enabled: false,
        clearDuration: 1 * 60,
        threshold: 5,
        demotionRank: 1,
        bypassRoleId: '',
    },
    activity: {
        enabled: false,
        type: 'WATCHING',
        value: 'for commands.',
    },
    status: 'online',
    deleteWallURLs: false,
}
